##
Mean posterior: 0.92
Estimated T on true tree: 2
Estimated T on HCC: 5
