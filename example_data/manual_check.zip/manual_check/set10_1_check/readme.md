##
Mean posterior: 0.52
Estimated T on true tree: 3
Estimated T on HCC: 32

 