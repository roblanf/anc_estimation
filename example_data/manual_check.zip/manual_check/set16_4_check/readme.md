##
Mean posterior: 0.95
Estimated T on true tree: 3
Estimated T on HCC: 12
