## 
Mean posterior : 0.55
Estimated T on true tree: 3
Estimated T on HCC: 16
