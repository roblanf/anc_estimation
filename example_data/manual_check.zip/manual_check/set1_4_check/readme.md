##
Mean posterior: 0.047
Estimated T on true tree: 1
Estimated T on estimatd tree: 8
 